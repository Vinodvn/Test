﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductManager.Models
{
    public class Message
    {
        public int MessageStatusId { get; set; }
        public string MessageText { get; set; }
    }
}